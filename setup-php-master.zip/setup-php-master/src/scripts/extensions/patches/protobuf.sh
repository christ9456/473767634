patch_protobuf() {
  mkdir -p third_party/wyhash
  cp ../../../../third_party/wyhash/* third_party/wyhash
}
